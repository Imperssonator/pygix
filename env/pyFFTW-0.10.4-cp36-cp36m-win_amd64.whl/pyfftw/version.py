
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.10.4'
version = '0.10.4'
full_version = '0.10.4'
git_revision = 'd96e74d900ed96a2700922a45a1fe450ef9cfbbf'
release = True
if not release:
    version = full_version

if __name__ == "__main__":
    print(short_version)
    print(version)
